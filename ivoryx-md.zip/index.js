const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const config = require('./config');

const { state, saveState } = useSingleFileAuthState('./session.json');

async function startBot() {
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const body = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
    const prefix = config.prefixes.find(p => body.startsWith(p));
    if (!prefix) return;

    const command = body.slice(prefix.length).trim().split(' ')[0].toLowerCase();

    if (command === 'menu') {
      await sock.sendMessage(from, {
        text: `🤖 *${config.botName}*

Voici les commandes disponibles:
- !menu
- !ping`
      });
    }

    if (command === 'ping') {
      await sock.sendMessage(from, { text: '🏓 Pong ! Le bot est actif.' });
    }
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect.error = Boom)?.output?.statusCode !== 401;
      if (shouldReconnect) startBot();
    }
  });

  sock.ev.on('creds.update', saveState);
}

startBot();