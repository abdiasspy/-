// config.js

module.exports = {
  botName: 'IVORYX MD',
  ownerName: 'Ton Nom',
  ownerNumber: ['225XXXXXXXXX'],
  messages: {
    success: '✅ Terminé !',
    admin: '❌ Cette commande est réservée aux admins.',
    botAdmin: '❌ Le bot doit être admin.',
    owner: '❌ Réservé au propriétaire.',
    group: '❌ Groupe uniquement.',
    private: '❌ Privé uniquement.',
    wait: '⏳ Patiente...',
    error: '❌ Une erreur est survenue.',
  },
  autoRead: true,
  prefixes: ['!', '.', '/'],
}