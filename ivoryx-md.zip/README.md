# IVORYX MD - WhatsApp Bot

![WhatsApp Bot](https://img.shields.io/badge/WhatsApp-Bot-brightgreen)
![IVORYX MD](https://img.shields.io/badge/IVORYX-MD-blueviolet)
![License](https://img.shields.io/github/license/votre-utilisateur/ivoryx-md)

> Un Bot WhatsApp multi-fonctions puissant, rapide et open-source basé sur [Baileys](https://github.com/WhiskeySockets/Baileys).

## ✨ Fonctionnalités principales

- 📥 Téléchargement de vidéos YouTube, audio, TikTok, Instagram, etc.
- 🎮 Jeux et mini-jeux (devinette, pierre-papier-ciseaux…)
- 📂 OCR, génération de stickers, lecture de code QR
- 🧠 IA intégrée (ChatGPT, DALL·E si configurée)
- 📡 Auto-répondeur, anti-lien, anti-fake, anti-spam
- 👮‍♂️ Commandes Admin, gestion de groupes

## 📦 Installation

### 1. Cloner le repo

```bash
git clone https://github.com/votre-utilisateur/ivoryx-md.git
cd ivoryx-md
```

### 2. Installer les dépendances

```bash
npm install
```

### 3. Lancer le bot

```bash
npm start
```

## ⚙️ Configuration

Créez un fichier `.env` à la racine avec :

```env
BOT_NAME=IVORYX MD
OWNER_NUMBER=+225XXXXXXXXX
SESSION_ID=<Votre Session ID si persistante>
OPENAI_KEY=<clé facultative pour ChatGPT>
```

## 📜 Licence

Ce projet est sous licence MIT. Voir `LICENSE` pour plus d'infos.